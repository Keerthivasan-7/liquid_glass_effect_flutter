import 'dart:math' as math;
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/scheduler.dart';

import '../configuration/liquid_glass_config.dart';
import '../geometry/liquid_glass_shape.dart';
import '../rendering/liquid_glass_capabilities.dart';
import '../rendering/shader_manager.dart';
import 'liquid_glass_group.dart';
import 'liquid_glass_scope.dart';

/// A clipped optical surface that refracts the content painted behind it.
///
/// Inside a [LiquidGlassScope], `auto` uses a bounded captured-texture shader.
/// Outside a scope it uses the Impeller image-filter shader when available and
/// otherwise falls back to blur/tint. The foreground [child] remains sharp.
class LiquidGlass extends StatefulWidget {
  const LiquidGlass({
    required this.child,
    this.config = const LiquidGlassConfig(),
    this.shape = const LiquidGlassShape.roundedRectangle(),
    this.padding = EdgeInsets.zero,
    this.width,
    this.height,
    this.semanticLabel,
    this.interactive = false,
    this.interactionDuration = const Duration(milliseconds: 180),
    this.onRenderPathChanged,
    super.key,
  });

  final Widget child;
  final LiquidGlassConfig config;
  final LiquidGlassShape shape;
  final EdgeInsetsGeometry padding;
  final double? width;
  final double? height;
  final String? semanticLabel;

  /// Enables pointer-local optics and restrained hover/press scaling.
  ///
  /// This is visual feedback only and does not consume taps, so interactive
  /// descendants keep their normal gesture and semantic behavior.
  final bool interactive;

  /// Duration used to settle hover and press feedback.
  final Duration interactionDuration;

  /// Debug/diagnostic callback fired when the concrete renderer changes.
  final ValueChanged<LiquidGlassRenderPath>? onRenderPathChanged;

  @override
  State<LiquidGlass> createState() => _LiquidGlassState();
}

class _LiquidGlassState extends State<LiquidGlass>
    with TickerProviderStateMixin {
  late final AnimationController _animation;
  late final AnimationController _motionSettle;
  final GlobalKey _surfaceKey = GlobalKey();
  ui.FragmentShader? _filterShader;
  ui.FragmentShader? _captureShader;
  LiquidGlassCaptureHandle? _captureHandle;
  LiquidGlassMotionHandle? _motionHandle;
  bool _loadingFilter = false;
  bool _loadingCapture = false;
  bool _captureRetained = false;
  LiquidGlassRenderPath? _reportedPath;
  bool _hovered = false;
  bool _pressed = false;
  Offset _interactionPoint = Offset.zero;
  Offset _interactionVelocity = Offset.zero;
  Duration? _lastInteractionTime;

  @override
  void initState() {
    super.initState();
    _animation = AnimationController(
      vsync: this,
      duration: widget.config.animationDuration,
    );
    _motionSettle = AnimationController(
      vsync: this,
      duration: _settleDuration,
    );
    _loadUsefulShaders();
  }

  Duration get _settleDuration => Duration(
        microseconds: math.max(
          widget.interactionDuration.inMicroseconds * 4,
          320000,
        ),
      );

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final nextHandle = liquidGlassCaptureOf(context);
    if (_captureHandle != nextHandle) {
      if (_captureRetained) _captureHandle?.releaseCapture();
      _captureHandle?.removeListener(_handleChanged);
      _captureHandle = nextHandle;
      _captureHandle?.addListener(_handleChanged);
      _captureRetained = false;
    }
    final nextMotionHandle = liquidGlassMotionOf(context);
    if (_motionHandle != nextMotionHandle) {
      _motionHandle?.removeListener(_handleMotionChanged);
      _motionHandle = nextMotionHandle;
      _motionHandle?.addListener(_handleMotionChanged);
    }
    _syncCaptureRegistration();
    _loadUsefulShaders();
    _synchronizeAnimation();
  }

  void _handleChanged() {
    if (mounted) setState(() {});
  }

  void _handleMotionChanged() {
    if (mounted && widget.interactive) setState(() {});
  }

  @override
  void didUpdateWidget(covariant LiquidGlass oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.config.animationDuration != widget.config.animationDuration) {
      _animation.duration = widget.config.animationDuration;
    }
    if (oldWidget.interactionDuration != widget.interactionDuration) {
      _motionSettle.duration = _settleDuration;
    }
    if (oldWidget.config.renderer != widget.config.renderer) {
      _syncCaptureRegistration();
      _loadUsefulShaders();
    }
    if (oldWidget.onRenderPathChanged != widget.onRenderPathChanged) {
      _reportedPath = null;
    }
    _synchronizeAnimation();
  }

  bool get _mayUseFilter =>
      widget.config.renderer == LiquidGlassRenderer.auto ||
      widget.config.renderer == LiquidGlassRenderer.shader;

  bool get _mayUseCapture =>
      widget.config.renderer == LiquidGlassRenderer.auto ||
      widget.config.renderer == LiquidGlassRenderer.capture;

  void _syncCaptureRegistration() {
    final shouldRetain = _captureHandle != null && _mayUseCapture;
    if (shouldRetain == _captureRetained) return;
    if (shouldRetain) {
      _captureHandle!.retainCapture();
    } else {
      _captureHandle?.releaseCapture();
    }
    _captureRetained = shouldRetain;
  }

  Future<void> _loadUsefulShaders() async {
    if (_mayUseFilter &&
        LiquidGlassCapabilities.supportsShaderBackdropFilter &&
        _filterShader == null &&
        !_loadingFilter) {
      _loadingFilter = true;
      try {
        final program = await LiquidGlassShaderManager.loadFilter();
        if (mounted) setState(() => _filterShader = program.fragmentShader());
      } on Object catch (error) {
        assert(() {
          debugPrint('LiquidGlass filter shader unavailable: $error');
          return true;
        }());
      } finally {
        _loadingFilter = false;
      }
    }

    if (_mayUseCapture &&
        _captureHandle != null &&
        _captureShader == null &&
        !_loadingCapture) {
      _loadingCapture = true;
      try {
        final program = await LiquidGlassShaderManager.loadCapture();
        if (mounted) setState(() => _captureShader = program.fragmentShader());
      } on Object catch (error) {
        assert(() {
          debugPrint('LiquidGlass capture shader unavailable: $error');
          return true;
        }());
      } finally {
        _loadingCapture = false;
      }
    }
  }

  LiquidGlassRenderPath get _renderPath {
    final handle = _captureHandle;
    if (_mayUseCapture &&
        handle != null &&
        handle.captureSupported &&
        _captureShader != null) {
      return LiquidGlassRenderPath.capture;
    }
    if (_mayUseFilter &&
        LiquidGlassCapabilities.supportsShaderBackdropFilter &&
        _filterShader != null) {
      return LiquidGlassRenderPath.filter;
    }
    return LiquidGlassRenderPath.fallback;
  }

  void _reportRenderPath(LiquidGlassRenderPath path) {
    if (_reportedPath == path) return;
    _reportedPath = path;
    final callback = widget.onRenderPathChanged;
    if (callback == null) return;
    SchedulerBinding.instance.addPostFrameCallback((_) {
      if (mounted && _reportedPath == path) callback(path);
    });
  }

  void _synchronizeAnimation() {
    final media = MediaQuery.maybeOf(context);
    final reduceMotion = (media?.disableAnimations ?? false) ||
        (media?.accessibleNavigation ?? false);
    final shouldAnimate = widget.config.animateLight &&
        widget.config.animationDuration.inMicroseconds > 0 &&
        !reduceMotion;
    if (shouldAnimate && !_animation.isAnimating) {
      _animation.repeat();
    } else if (!shouldAnimate && _animation.isAnimating) {
      _animation
        ..stop()
        ..value = 0;
    }
  }

  @override
  void dispose() {
    if (_captureRetained) _captureHandle?.releaseCapture();
    _captureHandle?.removeListener(_handleChanged);
    _motionHandle?.removeListener(_handleMotionChanged);
    _animation.dispose();
    _motionSettle.dispose();
    _filterShader?.dispose();
    _captureShader?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final media = MediaQuery.maybeOf(context);
    final reduceMotion = (media?.disableAnimations ?? false) ||
        (media?.accessibleNavigation ?? false);
    final interactionTarget = _pressed ? 1.0 : (_hovered ? 0.32 : 0.0);
    final scaleTarget = reduceMotion
        ? 1.0
        : _pressed
            ? 0.985
            : _hovered
                ? 1.008
                : 1.0;

    Widget surface = TweenAnimationBuilder<double>(
      duration: reduceMotion ? Duration.zero : widget.interactionDuration,
      curve: _pressed ? Curves.easeOutCubic : Curves.easeOutBack,
      tween: Tween<double>(end: widget.interactive ? interactionTarget : 0),
      builder: (context, interactionStrength, _) => AnimatedScale(
        scale: widget.interactive ? scaleTarget : 1,
        duration: reduceMotion ? Duration.zero : widget.interactionDuration,
        curve: _pressed ? Curves.easeOutCubic : Curves.easeOutBack,
        child: _buildSurface(interactionStrength),
      ),
    );

    if (widget.interactive) {
      surface = MouseRegion(
        onEnter: (event) => _trackInteraction(
          point: event.localPosition,
          delta: event.delta,
          timeStamp: event.timeStamp,
          hovered: true,
        ),
        onHover: (event) => _trackInteraction(
          point: event.localPosition,
          delta: event.delta,
          timeStamp: event.timeStamp,
        ),
        onExit: (_) => _releaseInteraction(hovered: false, pressed: false),
        child: Listener(
          behavior: HitTestBehavior.translucent,
          onPointerDown: (event) => _trackInteraction(
            point: event.localPosition,
            delta: event.delta,
            timeStamp: event.timeStamp,
            pressed: true,
          ),
          onPointerMove: (event) => _trackInteraction(
            point: event.localPosition,
            delta: event.delta,
            timeStamp: event.timeStamp,
          ),
          onPointerUp: (event) {
            _trackInteraction(
              point: event.localPosition,
              delta: event.delta,
              timeStamp: event.timeStamp,
            );
            _releaseInteraction(pressed: false);
          },
          onPointerCancel: (_) => _releaseInteraction(pressed: false),
          child: surface,
        ),
      );
    }

    return KeyedSubtree(
      key: _surfaceKey,
      child: Semantics(
        label: widget.semanticLabel,
        container: widget.semanticLabel != null,
        child: surface,
      ),
    );
  }

  void _trackInteraction({
    required Offset point,
    required Offset delta,
    required Duration timeStamp,
    bool? hovered,
    bool? pressed,
  }) {
    if (!mounted) return;
    final previousTime = _lastInteractionTime;
    final elapsed = previousTime == null
        ? 0.016
        : (timeStamp - previousTime).inMicroseconds / 1000000;
    final dt = elapsed.clamp(0.001, 0.05);
    final measuredVelocity = delta / dt;
    final nextVelocity = Offset.lerp(
      _interactionVelocity,
      measuredVelocity,
      0.45,
    )!;
    final nextHovered = hovered ?? _hovered;
    final nextPressed = pressed ?? _pressed;
    _motionSettle.stop();
    _motionSettle.value = 0;
    _lastInteractionTime = timeStamp;
    if (point == _interactionPoint &&
        nextVelocity == _interactionVelocity &&
        nextHovered == _hovered &&
        nextPressed == _pressed) {
      return;
    }
    setState(() {
      _interactionPoint = point;
      _interactionVelocity = nextVelocity;
      _hovered = nextHovered;
      _pressed = nextPressed;
    });
  }

  void _releaseInteraction({bool? hovered, bool? pressed}) {
    if (!mounted) return;
    setState(() {
      _hovered = hovered ?? _hovered;
      _pressed = pressed ?? _pressed;
      _lastInteractionTime = null;
    });
    _motionSettle.forward(from: 0);
  }

  Widget _buildSurface(double interactionStrength) => AnimatedBuilder(
        animation: Listenable.merge(<Listenable>[_animation, _motionSettle]),
        builder: (context, _) {
          final path = _renderPath;
          _reportRenderPath(path);
          return SizedBox(
            width: widget.width,
            height: widget.height,
            child: LayoutBuilder(
              builder: (context, constraints) {
                final size = Size(
                  constraints.hasBoundedWidth ? constraints.maxWidth : 0,
                  constraints.hasBoundedHeight ? constraints.maxHeight : 0,
                );
                final foreground = Padding(
                  padding: widget.padding,
                  child: widget.child,
                );
                final motion = _resolveMotion(size, interactionStrength);
                if (path == LiquidGlassRenderPath.capture) {
                  return _CaptureGlassSurface(
                    handle: _captureHandle!,
                    shader: _captureShader!,
                    config: widget.config,
                    shape: widget.shape,
                    animationValue: _animation.value,
                    interactionPoint: motion.point,
                    interactionStrength: motion.interactionStrength,
                    interactionVelocity: motion.velocity,
                    motionStrength: motion.motionStrength,
                    child: foreground,
                  );
                }
                return ClipPath(
                  clipper: _LiquidGlassClipper(widget.shape),
                  child: Stack(
                    fit: StackFit.passthrough,
                    children: <Widget>[
                      Positioned.fill(
                        child: _buildBackdrop(
                          path,
                          size,
                          motion,
                        ),
                      ),
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _GlassOverlayPainter(
                              config: widget.config,
                              shape: widget.shape,
                              applyTint: path == LiquidGlassRenderPath.fallback,
                            ),
                          ),
                        ),
                      ),
                      foreground,
                    ],
                  ),
                );
              },
            ),
          );
        },
      );

  Widget _buildBackdrop(
    LiquidGlassRenderPath path,
    Size size,
    _GlassMotionSample motion,
  ) {
    final shader = _filterShader;
    if (path == LiquidGlassRenderPath.filter &&
        shader != null &&
        size.width > 0 &&
        size.height > 0) {
      _bindFilterUniforms(shader, size, motion);
      return BackdropFilter(
        filter: ui.ImageFilter.shader(shader),
        child: const SizedBox.expand(),
      );
    }
    return BackdropFilter(
      filter: ui.ImageFilter.blur(
        sigmaX: widget.config.blurSigma,
        sigmaY: widget.config.blurSigma,
        tileMode: TileMode.clamp,
      ),
      child: const SizedBox.expand(),
    );
  }

  void _bindFilterUniforms(
    ui.FragmentShader shader,
    Size size,
    _GlassMotionSample motion,
  ) {
    final config = widget.config;
    final light = _animatedLight(config.lightDirection, _animation.value);
    final tint = config.tint;
    final absorption = config.absorptionColor;
    final lightColor = config.lightColor;
    // Slots 0 and 1 (u_size) are populated by the image-filter engine.
    shader
      ..setFloat(2, config.refractionStrength)
      ..setFloat(3, config.fresnelStrength)
      ..setFloat(4, config.specularStrength)
      ..setFloat(5, config.chromaticAberration)
      ..setFloat(6, config.thickness)
      ..setFloat(7, config.curvature)
      ..setFloat(8, config.edgeWidth)
      ..setFloat(9, config.maxDisplacement)
      ..setFloat(10, config.blurSigma)
      ..setFloat(11, config.saturation)
      ..setFloat(12, tint.r)
      ..setFloat(13, tint.g)
      ..setFloat(14, tint.b)
      ..setFloat(15, tint.a)
      ..setFloat(16, light.dx)
      ..setFloat(17, light.dy)
      ..setFloat(18, config.noise)
      ..setFloat(19, config.quality.index.toDouble())
      ..setFloat(20, widget.shape.resolvedRadius(size))
      ..setFloat(21, widget.shape.shaderValue)
      ..setFloat(22, _animation.value)
      ..setFloat(23, motion.point.dx)
      ..setFloat(24, motion.point.dy)
      ..setFloat(25, motion.interactionStrength)
      ..setFloat(26, config.refractiveIndex)
      ..setFloat(27, config.cornerSmoothing)
      ..setFloat(28, config.innerShadow)
      ..setFloat(29, config.roughness)
      ..setFloat(30, config.transmission)
      ..setFloat(31, absorption.r)
      ..setFloat(32, absorption.g)
      ..setFloat(33, absorption.b)
      ..setFloat(34, absorption.a)
      ..setFloat(35, config.absorptionStrength)
      ..setFloat(36, config.scatteringStrength)
      ..setFloat(37, config.dispersionStrength)
      ..setFloat(38, config.abbeNumber)
      ..setFloat(39, config.environmentStrength)
      ..setFloat(40, config.coatStrength)
      ..setFloat(41, config.coatRoughness)
      ..setFloat(42, config.coatRefractiveIndex)
      ..setFloat(43, config.thinFilmThickness)
      ..setFloat(44, config.thinFilmRefractiveIndex)
      ..setFloat(45, config.thinFilmStrength)
      ..setFloat(46, config.anisotropy)
      ..setFloat(47, config.anisotropyRotation)
      ..setFloat(48, config.causticStrength)
      ..setFloat(49, lightColor.r)
      ..setFloat(50, lightColor.g)
      ..setFloat(51, lightColor.b)
      ..setFloat(52, lightColor.a)
      ..setFloat(53, config.lightIntensity)
      ..setFloat(54, motion.velocity.dx)
      ..setFloat(55, motion.velocity.dy)
      ..setFloat(56, motion.motionStrength);
  }

  _GlassMotionSample _resolveMotion(Size size, double interactionStrength) {
    final settle = 1 - Curves.easeOutCubic.transform(_motionSettle.value);
    var point = _interactionPoint;
    var velocity = _normalizeVelocity(_interactionVelocity * settle, size);
    var strength = interactionStrength;

    final handle = _motionHandle;
    final box = _surfaceKey.currentContext?.findRenderObject();
    if (widget.interactive &&
        handle != null &&
        box is RenderBox &&
        box.hasSize) {
      final field = handle.motion;
      final localPoint = box.globalToLocal(field.globalPosition);
      final bounds = Offset.zero & box.size;
      final nearest = Offset(
        localPoint.dx.clamp(bounds.left, bounds.right),
        localPoint.dy.clamp(bounds.top, bounds.bottom),
      );
      final distance = (localPoint - nearest).distance;
      final radius = handle.influenceRadius;
      final influence = math.exp(-2.4 * math.pow(distance / radius, 2));
      final groupStrength = field.strength * influence;
      if (groupStrength > 0.001) {
        final localVelocity = box.globalToLocal(
              field.globalPosition + field.velocity,
            ) -
            localPoint;
        final normalizedGroupVelocity = _normalizeVelocity(localVelocity, size);
        final total = math.max(strength + groupStrength, 0.0001);
        velocity =
            (velocity * strength + normalizedGroupVelocity * groupStrength) /
                total;
        point = Offset.lerp(point, localPoint, groupStrength / total)!;
        strength = (math.max(strength, groupStrength) +
                math.min(strength, groupStrength) * 0.28)
            .clamp(0, 1.5);
      }
    }

    return _GlassMotionSample(
      point: point,
      velocity: velocity,
      interactionStrength: strength,
      motionStrength: strength * widget.config.motionStrength,
    );
  }

  Offset _normalizeVelocity(Offset velocity, Size size) {
    final shortest = math.max(math.min(size.width, size.height), 1);
    final scale = shortest * 14;
    return Offset(
      (velocity.dx / scale).clamp(-1.5, 1.5),
      (velocity.dy / scale).clamp(-1.5, 1.5),
    );
  }

  Offset _animatedLight(Offset light, double animationValue) {
    if (!widget.config.animateLight) return light;
    final angle = animationValue * math.pi * 2;
    return Offset(
      light.dx * math.cos(angle) - light.dy * math.sin(angle),
      light.dx * math.sin(angle) + light.dy * math.cos(angle),
    );
  }
}

class _CaptureGlassSurface extends SingleChildRenderObjectWidget {
  const _CaptureGlassSurface({
    required this.handle,
    required this.shader,
    required this.config,
    required this.shape,
    required this.animationValue,
    required this.interactionPoint,
    required this.interactionStrength,
    required this.interactionVelocity,
    required this.motionStrength,
    required super.child,
  });

  final LiquidGlassCaptureHandle handle;
  final ui.FragmentShader shader;
  final LiquidGlassConfig config;
  final LiquidGlassShape shape;
  final double animationValue;
  final Offset interactionPoint;
  final double interactionStrength;
  final Offset interactionVelocity;
  final double motionStrength;

  @override
  RenderObject createRenderObject(BuildContext context) =>
      _RenderCaptureGlassSurface(
        handle: handle,
        shader: shader,
        config: config,
        shape: shape,
        animationValue: animationValue,
        interactionPoint: interactionPoint,
        interactionStrength: interactionStrength,
        interactionVelocity: interactionVelocity,
        motionStrength: motionStrength,
      );

  @override
  void updateRenderObject(
    BuildContext context,
    covariant _RenderCaptureGlassSurface renderObject,
  ) {
    renderObject
      ..handle = handle
      ..shader = shader
      ..config = config
      ..shape = shape
      ..animationValue = animationValue
      ..interactionPoint = interactionPoint
      ..interactionStrength = interactionStrength
      ..interactionVelocity = interactionVelocity
      ..motionStrength = motionStrength;
  }
}

class _RenderCaptureGlassSurface extends RenderProxyBox
    implements LiquidGlassCaptureClient {
  _RenderCaptureGlassSurface({
    required LiquidGlassCaptureHandle handle,
    required ui.FragmentShader shader,
    required LiquidGlassConfig config,
    required LiquidGlassShape shape,
    required double animationValue,
    required Offset interactionPoint,
    required double interactionStrength,
    required Offset interactionVelocity,
    required double motionStrength,
  })  : _handle = handle,
        _shader = shader,
        _config = config,
        _shape = shape,
        _animationValue = animationValue,
        _interactionPoint = interactionPoint,
        _interactionStrength = interactionStrength,
        _interactionVelocity = interactionVelocity,
        _motionStrength = motionStrength;

  LiquidGlassCaptureHandle _handle;
  ui.FragmentShader _shader;
  LiquidGlassConfig _config;
  LiquidGlassShape _shape;
  double _animationValue;
  Offset _interactionPoint;
  double _interactionStrength;
  Offset _interactionVelocity;
  double _motionStrength;

  set handle(LiquidGlassCaptureHandle value) {
    if (_handle == value) return;
    if (attached) _handle.unregisterClient(this);
    _handle = value;
    if (attached) _handle.registerClient(this);
    markNeedsPaint();
  }

  set shader(ui.FragmentShader value) {
    if (_shader == value) return;
    _shader = value;
    markNeedsPaint();
  }

  set config(LiquidGlassConfig value) {
    if (_config == value) return;
    _config = value;
    _handle.requestCapture();
    markNeedsPaint();
  }

  set shape(LiquidGlassShape value) {
    if (_shape == value) return;
    _shape = value;
    markNeedsPaint();
  }

  set animationValue(double value) {
    if (_animationValue == value) return;
    _animationValue = value;
    markNeedsPaint();
  }

  set interactionPoint(Offset value) {
    if (_interactionPoint == value) return;
    _interactionPoint = value;
    markNeedsPaint();
  }

  set interactionStrength(double value) {
    if (_interactionStrength == value) return;
    _interactionStrength = value;
    markNeedsPaint();
  }

  set interactionVelocity(Offset value) {
    if (_interactionVelocity == value) return;
    _interactionVelocity = value;
    markNeedsPaint();
  }

  set motionStrength(double value) {
    if (_motionStrength == value) return;
    _motionStrength = value;
    markNeedsPaint();
  }

  @override
  void attach(PipelineOwner owner) {
    super.attach(owner);
    _handle.registerClient(this);
  }

  @override
  void detach() {
    _handle.unregisterClient(this);
    super.detach();
  }

  @override
  Rect captureBoundsIn(RenderBox scope) {
    if (!attached || !hasSize || size.isEmpty) return Rect.zero;
    final transform = getTransformTo(scope);
    final bounds = MatrixUtils.transformRect(transform, Offset.zero & size);
    final padding = _config.maxDisplacement + _config.blurSigma + 2;
    return bounds.inflate(padding).intersect(Offset.zero & scope.size);
  }

  @override
  void paint(PaintingContext context, Offset offset) {
    final canvas = context.canvas;
    final path = _shape.pathFor(size);
    final image = _handle.image;
    final scope = _handle.scopeRenderBox;
    var shaderPainted = false;

    if (image != null && scope != null && scope.attached && !size.isEmpty) {
      try {
        final requiredBounds = captureBoundsIn(scope);
        final captureRect = _handle.captureRect;
        if (!_containsRect(captureRect, requiredBounds)) {
          _handle.requestCapture();
        } else {
          final transform = getTransformTo(scope);
          final scopeOrigin =
              MatrixUtils.transformPoint(transform, Offset.zero);
          final captureOrigin = scopeOrigin - captureRect.topLeft;
          _bindCaptureUniforms(captureOrigin, captureRect.size, image);
          canvas
            ..save()
            ..translate(offset.dx, offset.dy)
            ..drawPath(path, Paint()..shader = _shader)
            ..restore();
          shaderPainted = true;
        }
      } on Object catch (error) {
        assert(() {
          debugPrint('LiquidGlass capture paint failed: $error');
          return true;
        }());
      }
    }

    if (!shaderPainted) {
      canvas
        ..save()
        ..translate(offset.dx, offset.dy)
        ..drawPath(path, Paint()..color = _config.tint)
        ..restore();
    }

    final foreground = child;
    if (foreground != null) {
      context.pushClipPath(
        needsCompositing,
        offset,
        Offset.zero & size,
        path,
        (childContext, childOffset) {
          childContext.paintChild(foreground, childOffset);
        },
        clipBehavior: Clip.antiAlias,
      );
    }
  }

  bool _containsRect(Rect outer, Rect inner) {
    const tolerance = 0.01;
    return !outer.isEmpty &&
        inner.left >= outer.left - tolerance &&
        inner.top >= outer.top - tolerance &&
        inner.right <= outer.right + tolerance &&
        inner.bottom <= outer.bottom + tolerance;
  }

  void _bindCaptureUniforms(Offset origin, Size scopeSize, ui.Image image) {
    final tint = _config.tint;
    final light = _animatedLight(_config.lightDirection);
    final absorption = _config.absorptionColor;
    final lightColor = _config.lightColor;
    _shader
      ..setFloat(0, size.width)
      ..setFloat(1, size.height)
      ..setFloat(2, scopeSize.width)
      ..setFloat(3, scopeSize.height)
      ..setFloat(4, origin.dx)
      ..setFloat(5, origin.dy)
      ..setFloat(6, _config.refractiveIndex)
      ..setFloat(7, _config.refractionStrength)
      ..setFloat(8, _config.fresnelStrength)
      ..setFloat(9, _config.specularStrength)
      ..setFloat(10, _config.chromaticAberration)
      ..setFloat(11, _config.thickness)
      ..setFloat(12, _config.curvature)
      ..setFloat(13, _config.cornerSmoothing)
      ..setFloat(14, _config.edgeWidth)
      ..setFloat(15, _config.maxDisplacement)
      ..setFloat(16, _config.blurSigma)
      ..setFloat(17, _config.saturation)
      ..setFloat(18, tint.r)
      ..setFloat(19, tint.g)
      ..setFloat(20, tint.b)
      ..setFloat(21, tint.a)
      ..setFloat(22, light.dx)
      ..setFloat(23, light.dy)
      ..setFloat(24, _config.noise)
      ..setFloat(25, _config.quality.index.toDouble())
      ..setFloat(26, _shape.resolvedRadius(size))
      ..setFloat(27, _shape.shaderValue)
      ..setFloat(28, _animationValue)
      ..setFloat(29, _interactionPoint.dx)
      ..setFloat(30, _interactionPoint.dy)
      ..setFloat(31, _interactionStrength)
      ..setFloat(32, _config.innerShadow)
      ..setFloat(33, _config.roughness)
      ..setFloat(34, _config.transmission)
      ..setFloat(35, absorption.r)
      ..setFloat(36, absorption.g)
      ..setFloat(37, absorption.b)
      ..setFloat(38, absorption.a)
      ..setFloat(39, _config.absorptionStrength)
      ..setFloat(40, _config.scatteringStrength)
      ..setFloat(41, _config.dispersionStrength)
      ..setFloat(42, _config.abbeNumber)
      ..setFloat(43, _config.environmentStrength)
      ..setFloat(44, _config.coatStrength)
      ..setFloat(45, _config.coatRoughness)
      ..setFloat(46, _config.coatRefractiveIndex)
      ..setFloat(47, _config.thinFilmThickness)
      ..setFloat(48, _config.thinFilmRefractiveIndex)
      ..setFloat(49, _config.thinFilmStrength)
      ..setFloat(50, _config.anisotropy)
      ..setFloat(51, _config.anisotropyRotation)
      ..setFloat(52, _config.causticStrength)
      ..setFloat(53, lightColor.r)
      ..setFloat(54, lightColor.g)
      ..setFloat(55, lightColor.b)
      ..setFloat(56, lightColor.a)
      ..setFloat(57, _config.lightIntensity)
      ..setFloat(58, _interactionVelocity.dx)
      ..setFloat(59, _interactionVelocity.dy)
      ..setFloat(60, _motionStrength)
      ..setImageSampler(0, image);
  }

  Offset _animatedLight(Offset light) {
    if (!_config.animateLight) return light;
    final angle = _animationValue * math.pi * 2;
    return Offset(
      light.dx * math.cos(angle) - light.dy * math.sin(angle),
      light.dx * math.sin(angle) + light.dy * math.cos(angle),
    );
  }
}

@immutable
class _GlassMotionSample {
  const _GlassMotionSample({
    required this.point,
    required this.velocity,
    required this.interactionStrength,
    required this.motionStrength,
  });

  final Offset point;
  final Offset velocity;
  final double interactionStrength;
  final double motionStrength;
}

class _LiquidGlassClipper extends CustomClipper<Path> {
  const _LiquidGlassClipper(this.shape);

  final LiquidGlassShape shape;

  @override
  Path getClip(Size size) => shape.pathFor(size);

  @override
  bool shouldReclip(_LiquidGlassClipper oldClipper) =>
      oldClipper.shape != shape;
}

class _GlassOverlayPainter extends CustomPainter {
  const _GlassOverlayPainter({
    required this.config,
    required this.shape,
    required this.applyTint,
  });

  final LiquidGlassConfig config;
  final LiquidGlassShape shape;
  final bool applyTint;

  @override
  void paint(Canvas canvas, Size size) {
    if (size.isEmpty) return;
    final path = shape.pathFor(size);
    if (applyTint) canvas.drawPath(path, Paint()..color = config.tint);
    if (config.borderWidth <= 0) return;

    final light = config.lightDirection;
    final begin = Alignment(light.dx.clamp(-1, 1), light.dy.clamp(-1, 1));
    final end = Alignment(-begin.x, -begin.y);
    final shader = LinearGradient(
      begin: begin,
      end: end,
      colors: <Color>[
        Colors.white.withValues(alpha: 0.34),
        Colors.white.withValues(alpha: 0.025),
        Colors.black.withValues(alpha: 0.08),
      ],
      stops: const <double>[0, 0.58, 1],
    ).createShader(Offset.zero & size);
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = config.borderWidth
        ..shader = shader,
    );
  }

  @override
  bool shouldRepaint(_GlassOverlayPainter oldDelegate) =>
      oldDelegate.config != config ||
      oldDelegate.shape != shape ||
      oldDelegate.applyTint != applyTint;
}
